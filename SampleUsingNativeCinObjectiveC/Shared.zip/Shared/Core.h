//
// Created by Pawel Klapuch on 14/05/2017.
//

#ifdef __cplusplus
extern "C" {
#endif

#include <stdio.h>
    
#ifndef _Core_
#define _Core_

const char* version();
    
#endif

#ifdef __cplusplus
}
#endif

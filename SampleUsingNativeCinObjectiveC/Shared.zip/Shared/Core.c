//
// Created by Pawel Klapuch on 14/05/2017.
//

#include "Core.h"
#include <stdlib.h>

const char* version()
{
    return "1.0";
}

